package dhbw.teamgold.engine.behavior;

/**
 * Implementation of InitializeArguments. Currently empty
 * 
 * @author Daniel Spaniol
 */
public class InitializeArgumentsImpl implements InitializeArguments {
}
