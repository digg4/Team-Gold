package dhbw.teamgold.engine.behavior;

/**
 * Additional information that is useful for initialization. This is currently
 * empty but may be extended in the future.
 * 
 * @author Daniel Spaniol
 */
public interface InitializeArguments {
}
