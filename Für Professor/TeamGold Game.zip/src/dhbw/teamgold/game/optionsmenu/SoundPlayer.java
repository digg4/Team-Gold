package dhbw.teamgold.game.optionsmenu;

import dhbw.teamgold.engine.core.GameObject;
import dhbw.teamgold.engine.core.PrototypedPrefab;
import dhbw.teamgold.engine.core.services.AssetsService;
import dhbw.teamgold.engine.service.Services;

public class SoundPlayer extends PrototypedPrefab {
	AssetsService assetsService = Services.get(AssetsService.class);
	@Override
	protected void initializeGameObject(GameObject object) {
	
		
	}
}
