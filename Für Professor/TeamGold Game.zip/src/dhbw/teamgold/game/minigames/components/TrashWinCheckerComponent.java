package dhbw.teamgold.game.minigames.components;

import dhbw.teamgold.engine.core.Component;

public class TrashWinCheckerComponent extends Component {

	
	
}
