package dhbw.teamgold.game.common.services;

import dhbw.teamgold.engine.service.Service;

public interface WinLoseService extends Service {

	void win();
	
	void lose();
	
}
